var verticalPosition;
var verticalPositionBefore;
var previousThumbnailId;
var thumbnailIdNow;
var windowWidth;
var windowHeight;
var isDesignContainer1Open = false;
var isDesignContainer2Open = false;